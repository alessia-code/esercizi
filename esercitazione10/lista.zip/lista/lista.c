
#include "lista.h"


#include<stdio.h>
#include<stdlib.h>

TipoLista listaVuota () { return NULL ;}

int estVuota ( TipoLista l ) { return ( l == NULL ) ;}

TipoLista cons ( T e , TipoLista l ) {
  TipoLista nuovo = ( TipoLista ) malloc ( sizeof ( TipoNodo));
  nuovo -> info = e ;
  nuovo -> next = l ;
  return nuovo ;
}

T car ( TipoLista l ) {
  if ( l == NULL ) {
  printf ( " ERRORE : lista vuota \n " ) ;
  exit (1) ;
  }
  return l -> info ;
}

TipoLista cdr ( TipoLista l ) {
  if ( l == NULL ) {
  printf ( " ERRORE : lista vuota \n " ) ;
  exit (1) ;
  }
  return l -> next ;
}

int length ( TipoLista l ) {
  if ( estVuota ( l ) ) return 0;
  return 1 + length ( cdr ( l ) ) ;
}

TipoLista append ( TipoLista l , T e ) {
  if ( estVuota ( l ) ) {
  return cons (e , l ) ;
  }
  return cons ( car ( l ) , append ( cdr ( l ) ,e ) ) ;
}

TipoLista concat ( TipoLista l1 , TipoLista l2 ) {
  if ( estVuota ( l2 ) ) {
  return ( l1 ) ;
  }
  return ( concat ( append ( l1 , car ( l2 ) ) , cdr ( l2 ) ) ) ;
}

T get ( TipoLista l , int i ) {
  if ( i < 0 || estVuota ( l ) ) {
    printf ( " ERRORE : lista vuota o indice fuori dai limiti !\n " ) ;
  exit (1) ;
  }
  if ( i ==0) return car ( l ) ;
    return get ( cdr ( l ) ,i -1) ;
}

TipoLista ins ( TipoLista l , int i , T e ) {
  if ( i < 0 || (i >0 && estVuota ( l ) ) ) {
    printf ( " ERRORE : indice fuori dai limiti !\n " ) ;
  exit (1) ;
  }
  if ( i ==0) return cons (e , l ) ;
    return ( cons ( car ( l ) , ins ( cdr ( l ) , i -1 , e ) ) ) ;
}

