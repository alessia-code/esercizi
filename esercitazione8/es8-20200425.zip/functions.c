#pragma once

#include "scl.h"
#include "functions.h"
#include<stdlib.h>


