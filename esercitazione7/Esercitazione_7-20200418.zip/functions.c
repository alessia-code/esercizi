#include <stdlib.h>
#include <stdio.h>
#include "functions.h"

bool tuttiMinuscoli(char *s){
  // implement me
  return false;
}

void converti(char *s){
  // implement me
  return;
}

int contaParentesi(char *s){
  // implement me
  return 0;
}

void concatenate(char* dest, char* src){
  // implement me
  return;
}

float prodotto(float a[], int n){
  // implement me
  return 0;
}


float SCL_media(TipoSCL head_ptr){
  // implement me
  return -1;
}

void SCL_integral(TipoSCL head_ptr){
  // implement me
}

float SCL_dot(TipoSCL head1_ptr, TipoSCL head2_ptr) {
  // implement me
  return -1;
}



