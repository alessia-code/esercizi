#pragma once

typedef float TipoInfoSCL ;
struct ElemSCL {
TipoInfoSCL info ;
struct ElemSCL * next ;
};
typedef struct ElemSCL TipoNodoSCL ;
typedef TipoNodoSCL * TipoSCL ;




